package day0714.Work;

import java.io.IOException;

public class RunJavaMemo {
	public static void main(String[] args) throws ClassNotFoundException, IOException {
			new JavaMemo();			
	}
}
